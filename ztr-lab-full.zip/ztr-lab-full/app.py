import os, io, csv, json, uuid, base64
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path

from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_file
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

from db import init_db, get_db
from backtest import run_ztr_backtest, parse_ohlc_csv

BASE = Path(__file__).resolve().parent
UPLOAD_DIR = Path(os.environ.get("UPLOAD_DIR", str(BASE / "uploads")))
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
ALLOWED_IMAGES = {"png", "jpg", "jpeg", "webp"}
ALLOWED_CSV = {"csv"}

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "dev-only-change-this-secret")
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024
app.config["UPLOAD_FOLDER"] = str(UPLOAD_DIR)
init_db()

@app.teardown_appcontext
def close_db(exception=None):
    db = getattr(__import__("flask").g, "_database", None)
    # The connection is stored by db.get_db on Flask's g; close it if present.
    try:
        from flask import g
        conn = g.pop("db", None)
        if conn is not None:
            conn.close()
    except Exception:
        pass

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

def allowed(filename, extensions):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in extensions

@app.route("/")
def home():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))
    return render_template("landing.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not email or len(password) < 10:
            flash("Enter an email and a password of at least 10 characters.", "error")
            return render_template("auth.html", mode="register")
        db = get_db()
        try:
            db.execute("INSERT INTO users(email,password_hash,created_at) VALUES(?,?,?)",
                       (email, generate_password_hash(password), datetime.now(timezone.utc).isoformat()))
            db.commit()
        except Exception:
            flash("That email may already be registered.", "error")
            return render_template("auth.html", mode="register")
        user = db.execute("SELECT id,email FROM users WHERE email=?", (email,)).fetchone()
        session.clear()
        session["user_id"] = user["id"]
        session["email"] = user["email"]
        return redirect(url_for("dashboard"))
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        db = get_db()
        user = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if not user or not check_password_hash(user["password_hash"], password):
            flash("Email or password is incorrect.", "error")
        else:
            session.clear()
            session["user_id"] = user["id"]
            session["email"] = user["email"]
            return redirect(url_for("dashboard"))
    return render_template("auth.html", mode="login")

@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect(url_for("home"))

@app.route("/dashboard")
@login_required
def dashboard():
    db = get_db()
    trades = db.execute("SELECT * FROM trades WHERE user_id=? ORDER BY trade_date DESC LIMIT 200",
                        (session["user_id"],)).fetchall()
    images = db.execute("SELECT * FROM screenshots WHERE user_id=? ORDER BY created_at DESC",
                        (session["user_id"],)).fetchall()
    runs = db.execute("SELECT * FROM backtest_runs WHERE user_id=? ORDER BY created_at DESC LIMIT 20",
                      (session["user_id"],)).fetchall()
    return render_template("dashboard.html", trades=trades, images=images, runs=runs)

@app.route("/trades", methods=["POST"])
@login_required
def add_trade():
    f = request.form
    try:
        entry = float(f.get("entry") or 0)
        stop = float(f.get("stop") or 0)
        exit_price = float(f.get("exit_price") or 0)
        if entry <= 0 or stop <= 0 or exit_price <= 0 or entry == stop:
            raise ValueError()
        side = f.get("side", "Long")
        gross_r = ((exit_price-entry)/abs(entry-stop)) if side == "Long" else ((entry-exit_price)/abs(entry-stop))
        cost_r = max(0, float(f.get("cost_r") or 0))
        net_r = gross_r - cost_r
        db = get_db()
        db.execute("""INSERT INTO trades(user_id,trade_date,instrument,zone_tf,side,zone_top,zone_bottom,entry,stop,target,exit_price,status,cost_r,gross_r,net_r,session,sweep,structure_break,notes)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (session["user_id"],f.get("trade_date") or datetime.now().isoformat(),f.get("instrument","US30"),f.get("zone_tf","4H"),side,
         f.get("zone_top") or None,f.get("zone_bottom") or None,entry,stop,f.get("target") or None,exit_price,
         f.get("status","Closed"),cost_r,gross_r,net_r,f.get("session","Unknown"),f.get("sweep","Unclear"),f.get("structure_break","Unclear"),f.get("notes","")))
        db.commit()
        flash(f"Trade saved: {net_r:.2f}R net.", "success")
    except (ValueError, TypeError):
        flash("Enter valid positive entry, stop and exit prices; entry and stop must differ.", "error")
    return redirect(url_for("dashboard"))

@app.route("/trades/<int:trade_id>/delete", methods=["POST"])
@login_required
def delete_trade(trade_id):
    db = get_db()
    db.execute("DELETE FROM trades WHERE id=? AND user_id=?", (trade_id, session["user_id"]))
    db.commit()
    return redirect(url_for("dashboard"))

@app.route("/screenshots", methods=["POST"])
@login_required
def upload_screenshot():
    f = request.files.get("image")
    if not f or not f.filename or not allowed(f.filename, ALLOWED_IMAGES):
        flash("Upload a PNG, JPG, JPEG or WebP image.", "error")
        return redirect(url_for("dashboard"))
    ext = f.filename.rsplit(".",1)[1].lower()
    safe_name = f"{uuid.uuid4().hex}.{ext}"
    path = UPLOAD_DIR / safe_name
    f.save(path)
    db = get_db()
    db.execute("INSERT INTO screenshots(user_id,filename,original_name,instrument,zone_tf,notes,created_at) VALUES(?,?,?,?,?,?,?)",
               (session["user_id"],safe_name,secure_filename(f.filename),request.form.get("instrument","Unknown"),
                request.form.get("zone_tf","Unknown"),request.form.get("notes",""),datetime.now(timezone.utc).isoformat()))
    db.commit()
    flash("Screenshot uploaded. Run AI review to analyse it.", "success")
    return redirect(url_for("dashboard"))

@app.route("/uploads/<filename>")
@login_required
def uploaded_file(filename):
    db = get_db()
    row = db.execute("SELECT id FROM screenshots WHERE filename=? AND user_id=?", (filename, session["user_id"])).fetchone()
    if not row:
        return "Not found", 404
    return send_file(UPLOAD_DIR / filename)

@app.route("/screenshots/<int:image_id>/analyse", methods=["POST"])
@login_required
def analyse_screenshot(image_id):
    db = get_db()
    image_row = db.execute("SELECT * FROM screenshots WHERE id=? AND user_id=?", (image_id, session["user_id"])).fetchone()
    if not image_row:
        flash("Screenshot not found.", "error")
        return redirect(url_for("dashboard"))
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        flash("AI review is not configured yet. Set OPENAI_API_KEY in the hosting environment.", "error")
        return redirect(url_for("dashboard"))
    try:
        from openai import OpenAI
        path = UPLOAD_DIR / image_row["filename"]
        mime = {".jpg":"image/jpeg", ".jpeg":"image/jpeg", ".png":"image/png", ".webp":"image/webp"}.get(path.suffix.lower(), "image/jpeg")
        data_url = "data:" + mime + ";base64," + base64.b64encode(path.read_bytes()).decode()
        client = OpenAI(api_key=api_key)
        prompt = f"""Review this chart screenshot against this user's Zone Touch & Reaction strategy.
Instrument label: {image_row['instrument']}; zone timeframe label: {image_row['zone_tf']}; entry confirmation timeframe: 15m.
Rules: zone is a manually identified candle at a swing high/low; boundaries are the full candle high-to-low including wick and body. A swing is more extreme than the two bars before and after and is known only after two right-side bars close. Require price to move away at least 1.0 x ATR(14) within five completed zone-timeframe candles. First touch only. For entry, on 15m require a sweep of a previously confirmed local swing and a later 15m close beyond the latest confirmed opposing swing; entry would be next 15m open. Stop beyond the sweep/confirmation sequence extreme plus 0.1 x 15m ATR; target 2R.
Return sections: (1) Visible facts, (2) rule checklist with Pass/Fail/Unclear, (3) possible zone bounds and entry/stop/target only if legible, (4) missing information, (5) risks and alternative interpretations. Never invent prices, times, indicators, or claim profitability from a single screenshot. State when the screenshot is insufficient."""
        response = client.chat.completions.create(
            model=os.environ.get("OPENAI_VISION_MODEL","gpt-4.1-mini"),
            messages=[{"role":"user","content":[{"type":"text","text":prompt},{"type":"image_url","image_url":{"url":data_url}}]}],
            max_tokens=1300
        )
        analysis = response.choices[0].message.content or "No analysis returned."
        db.execute("UPDATE screenshots SET analysis=? WHERE id=? AND user_id=?", (analysis,image_id,session["user_id"]))
        db.commit()
        flash("AI screenshot review complete.", "success")
    except Exception as e:
        app.logger.exception("Screenshot analysis failed")
        flash("Analysis failed. Check the AI API key, model access and server logs.", "error")
    return redirect(url_for("dashboard") + f"#image-{image_id}")

@app.route("/screenshots/<int:image_id>/delete", methods=["POST"])
@login_required
def delete_screenshot(image_id):
    db = get_db()
    row = db.execute("SELECT filename FROM screenshots WHERE id=? AND user_id=?", (image_id,session["user_id"])).fetchone()
    if row:
        try: (UPLOAD_DIR / row["filename"]).unlink(missing_ok=True)
        except Exception: pass
        db.execute("DELETE FROM screenshots WHERE id=? AND user_id=?", (image_id,session["user_id"]))
        db.commit()
    return redirect(url_for("dashboard"))

@app.route("/backtest", methods=["GET","POST"])
@login_required
def backtest():
    if request.method == "GET":
        return render_template("backtest.html")
    zone_file = request.files.get("zone_csv")
    entry_file = request.files.get("entry_csv")
    instrument = request.form.get("instrument","EURUSD")
    zone_tf = request.form.get("zone_tf","4H")
    risk_pct = float(request.form.get("risk_pct") or 0.25)
    target_r = float(request.form.get("target_r") or 2.0)
    atr_mult = float(request.form.get("atr_mult") or 1.0)
    if not zone_file or not entry_file or not allowed(zone_file.filename,ALLOWED_CSV) or not allowed(entry_file.filename,ALLOWED_CSV):
        flash("Upload both source-timeframe OHLC CSV and 15-minute OHLC CSV files.", "error")
        return redirect(url_for("backtest"))
    try:
        zone_bars = parse_ohlc_csv(zone_file.stream)
        entry_bars = parse_ohlc_csv(entry_file.stream)
        result = run_ztr_backtest(zone_bars,entry_bars,instrument,zone_tf,risk_pct,target_r,atr_mult)
        db = get_db()
        db.execute("INSERT INTO backtest_runs(user_id,instrument,zone_tf,params_json,results_json,created_at) VALUES(?,?,?,?,?,?)",
                   (session["user_id"],instrument,zone_tf,json.dumps({"risk_pct":risk_pct,"target_r":target_r,"atr_mult":atr_mult}),
                    json.dumps(result),datetime.now(timezone.utc).isoformat()))
        db.commit()
        return render_template("backtest_results.html", result=result, instrument=instrument, zone_tf=zone_tf,
                               params={"risk_pct":risk_pct,"target_r":target_r,"atr_mult":atr_mult})
    except Exception as e:
        flash(f"Could not run backtest: {e}", "error")
        return redirect(url_for("backtest"))

@app.route("/export.csv")
@login_required
def export_csv():
    db = get_db()
    rows = db.execute("SELECT * FROM trades WHERE user_id=? ORDER BY trade_date", (session["user_id"],)).fetchall()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["trade_date","instrument","zone_tf","side","entry","stop","target","exit_price","status","cost_r","gross_r","net_r","session","sweep","structure_break","notes"])
    for r in rows:
        writer.writerow([r[k] for k in ["trade_date","instrument","zone_tf","side","entry","stop","target","exit_price","status","cost_r","gross_r","net_r","session","sweep","structure_break","notes"]])
    from flask import Response
    return Response(output.getvalue(), mimetype="text/csv", headers={"Content-Disposition":"attachment; filename=ztr-trades.csv"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT",5000)), debug=os.environ.get("FLASK_DEBUG")=="1")
