# ZTR Lab Full — deployable MVP

A Flask web app for the Zone Touch & Reaction (ZTR) research workflow:
- Individual user accounts and password hashing
- Per-user trade journal with gross/net R calculation
- Screenshot uploads and optional AI vision review via OpenAI API
- CSV-based historical backtest prototype with separate zone-timeframe and 15-minute OHLC files
- Backtest run history, trade export, and deployment configuration for Render

## Local run

Python 3.10+ recommended.

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
export FLASK_SECRET_KEY="replace-with-a-long-random-secret"
export OPENAI_API_KEY="your-api-key"  # optional; needed only for AI image analysis
python app.py
```

Open http://127.0.0.1:5000.

## Deploy to Render

1. Put this project in a private GitHub repository.
2. In Render, create a new Web Service from the repository.
3. Render can read `render.yaml`; check the service settings and persistent disk availability for your plan.
4. Set `OPENAI_API_KEY` in the service environment to enable screenshot analysis. Keep it secret; never put it in frontend JavaScript.
5. Set/confirm a persistent disk mounted at `/var/data` so SQLite and uploaded images persist. For multi-worker production use, SQLite should be replaced by managed PostgreSQL and uploads by object storage.
6. Use HTTPS and test register/login, uploads, AI review, export and backtest before sharing the URL.

## OHLC CSV format

Upload two CSVs: (1) zone timeframe candles and (2) 15-minute candles. Required headers:

```csv
timestamp,open,high,low,close
2025-01-01T00:00:00Z,1.1000,1.1020,1.0990,1.1010
```

ISO timestamps are required. CSVs should be sorted chronologically (the parser sorts them), contain at least 100 bars, use the same broker/data source where possible, and have clear timezone conventions. The zone CSV must be the selected 1H, 4H, or Daily timeframe; the entry CSV must be 15m. Do not include synthetic rows.

## Important limitations / validation status

This is a deployable MVP, not a validated trading system:
- The backtest engine is a transparent prototype of the specified ZTR rules, not a certified engine. Inspect the code and validate it against hand-labelled examples before relying on metrics.
- OHLC bar simulation cannot always determine intrabar event order. The engine uses conservative stop-first handling when stop and target both appear hit in one candle.
- Spread, commission, slippage, financing, market gaps, broker-specific contract sizing and session/news filters are not simulated in this version.
- Results can be biased by data gaps, timezones, price-feed differences, overlapping zones, ambiguous swing interpretation and parameter selection.
- The prototype stores screenshots on the server disk and uses SQLite. For production/multi-user scale, use PostgreSQL, object storage, CSRF protection, rate limiting, password reset, email verification, secure cookies, and a formal security review.
- AI screenshot review is qualitative and cannot reliably reconstruct hidden candles or prices from a screenshot. It is not financial advice.
- No broker connection, live signals, or order execution is included.

## Suggested next milestones

1. Validate engine with a small, manually labelled set of trades for US30, XAUUSD and EURUSD.
2. Replace SQLite with PostgreSQL and local image storage with private object storage.
3. Add CSRF protection, account recovery, email verification, audit logging and secure session settings.
4. Add data-provider adapters with explicit licensing and timezone/session metadata.
5. Add full parameter sweeps, out-of-sample and walk-forward testing, trade equity curve, MAE/MFE and cost models.
