import os, sqlite3
from pathlib import Path
from flask import g

BASE = Path(__file__).resolve().parent
DB_PATH = os.environ.get("DATABASE_PATH", str(BASE / "ztr.sqlite3"))

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

def init_db():
    db = sqlite3.connect(DB_PATH)
    db.execute("PRAGMA foreign_keys = ON")
    db.executescript("""
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS trades(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      trade_date TEXT NOT NULL, instrument TEXT NOT NULL, zone_tf TEXT NOT NULL, side TEXT NOT NULL,
      zone_top REAL, zone_bottom REAL, entry REAL NOT NULL, stop REAL NOT NULL, target REAL,
      exit_price REAL NOT NULL, status TEXT NOT NULL, cost_r REAL NOT NULL DEFAULT 0,
      gross_r REAL NOT NULL, net_r REAL NOT NULL, session TEXT, sweep TEXT, structure_break TEXT, notes TEXT
    );
    CREATE TABLE IF NOT EXISTS screenshots(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      filename TEXT NOT NULL, original_name TEXT NOT NULL, instrument TEXT, zone_tf TEXT, notes TEXT,
      analysis TEXT, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS backtest_runs(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      instrument TEXT NOT NULL, zone_tf TEXT NOT NULL, params_json TEXT NOT NULL,
      results_json TEXT NOT NULL, created_at TEXT NOT NULL
    );
    """)
    db.commit()
    db.close()
