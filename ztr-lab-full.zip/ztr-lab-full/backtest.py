import csv, math
from datetime import datetime

REQUIRED = {"timestamp","open","high","low","close"}

def parse_ohlc_csv(stream):
    # Expected headers: timestamp,open,high,low,close; volume optional.
    if hasattr(stream, "read"):
        raw = stream.read()
    else:
        raw = stream
    if isinstance(raw, bytes):
        raw = raw.decode("utf-8-sig")
    reader = csv.DictReader(raw.splitlines())
    if not reader.fieldnames:
        raise ValueError("CSV is empty.")
    normalized = {h.strip().lower(): h for h in reader.fieldnames}
    if not REQUIRED.issubset(normalized):
        raise ValueError("CSV headers must include timestamp,open,high,low,close.")
    bars=[]
    for row in reader:
        try:
            ts = row[normalized["timestamp"]].strip()
            dt = datetime.fromisoformat(ts.replace("Z","+00:00"))
            bar = {"timestamp":dt,"open":float(row[normalized["open"]]),"high":float(row[normalized["high"]]),
                   "low":float(row[normalized["low"]]),"close":float(row[normalized["close"]])}
            if bar["high"] < max(bar["open"],bar["close"]) or bar["low"] > min(bar["open"],bar["close"]) or bar["high"] < bar["low"]:
                raise ValueError("Invalid OHLC candle.")
            bars.append(bar)
        except Exception as e:
            raise ValueError(f"Invalid CSV row {reader.line_num}: {e}")
    bars.sort(key=lambda x:x["timestamp"])
    if len(bars) < 100:
        raise ValueError("At least 100 bars are recommended for a meaningful test.")
    return bars

def atr(bars, period=14):
    tr=[]
    prev=None
    for b in bars:
        tr.append(b["high"]-b["low"] if prev is None else max(b["high"]-b["low"],abs(b["high"]-prev),abs(b["low"]-prev)))
        prev=b["close"]
    out=[None]*len(bars)
    for i in range(period-1,len(bars)):
        out[i]=sum(tr[i-period+1:i+1])/period
    return out

def swing_zones(bars, atr_mult=1.0):
    # Emits zones only once swing and displacement are knowable, avoiding lookahead.
    av=atr(bars,14)
    zones=[]
    for i in range(2,len(bars)-2):
        high=bars[i]["high"] > max(bars[j]["high"] for j in [i-2,i-1,i+1,i+2])
        low=bars[i]["low"] < min(bars[j]["low"] for j in [i-2,i-1,i+1,i+2])
        if not high and not low: continue
        known_at=i+2
        # Look for displacement within five completed source bars after swing confirmation.
        end=min(len(bars)-1, i+5)
        direction="Short" if high else "Long"
        passed=False; creation=None
        for j in range(known_at,end+1):
            if av[j] is None: continue
            move=(bars[i]["high"]-bars[j]["close"]) if direction=="Short" else (bars[j]["close"]-bars[i]["low"])
            if move >= atr_mult*av[j]:
                passed=True; creation=j; break
        if passed:
            zones.append({"swing_index":i,"known_index":known_at,"creation_index":creation,
                          "top":bars[i]["high"],"bottom":bars[i]["low"],"side":direction,
                          "source_at":bars[creation]["timestamp"].isoformat(),"used":False})
    return zones

def run_ztr_backtest(zone_bars, entry_bars, instrument="EURUSD", zone_tf="4H", risk_pct=0.25, target_r=2.0, atr_mult=1.0):
    zones=swing_zones(zone_bars,atr_mult)
    e_atr=atr(entry_bars,14)
    # Confirmed 15m swings available only after the two right-side candles close.
    swings=[]
    for i in range(2,len(entry_bars)-2):
        if entry_bars[i]["high"] > max(entry_bars[j]["high"] for j in [i-2,i-1,i+1,i+2]):
            swings.append({"index":i,"known":i+2,"type":"high","price":entry_bars[i]["high"]})
        if entry_bars[i]["low"] < min(entry_bars[j]["low"] for j in [i-2,i-1,i+1,i+2]):
            swings.append({"index":i,"known":i+2,"type":"low","price":entry_bars[i]["low"]})
    trades=[]
    # map source zone creation to entry timeline, then only process entries after it is known.
    for z in zones:
        creation_dt=zone_bars[z["creation_index"]]["timestamp"]
        touches=[]
        for k,b in enumerate(entry_bars):
            if b["timestamp"] > creation_dt and b["high"] >= z["bottom"] and b["low"] <= z["top"]:
                touches.append(k)
        if not touches: continue
        touch=touches[0]
        deadline=min(len(entry_bars)-2,touch+8)
        # Zone far-edge close invalidation; wait for sweep then subsequent break.
        seq_end=None
        for k in range(touch,deadline+1):
            b=entry_bars[k]
            invalid=(b["close"] < z["bottom"]) if z["side"]=="Long" else (b["close"] > z["top"])
            if invalid: break
            available=[s for s in swings if s["known"] < k]
            if z["side"]=="Long":
                prev_lows=[s for s in available if s["type"]=="low" and s["price"]>b["low"]]
                prev_highs=[s for s in available if s["type"]=="high"]
                if not prev_lows or not prev_highs: continue
                swept=any(entry_bars[k]["low"] < s["price"] for s in prev_lows)
                if swept:
                    # break can occur on a later candle; find first close above latest known swing high
                    for m in range(k+1,deadline+1):
                        prior_highs=[s for s in swings if s["type"]=="high" and s["known"] < m]
                        if prior_highs and entry_bars[m]["close"] > prior_highs[-1]["price"]:
                            seq_end=m; break
                    if seq_end is not None: break
            else:
                prev_highs=[s for s in available if s["type"]=="high" and s["price"]<b["high"]]
                prev_lows=[s for s in available if s["type"]=="low"]
                if not prev_highs or not prev_lows: continue
                swept=any(entry_bars[k]["high"] > s["price"] for s in prev_highs)
                if swept:
                    for m in range(k+1,deadline+1):
                        prior_lows=[s for s in swings if s["type"]=="low" and s["known"] < m]
                        if prior_lows and entry_bars[m]["close"] < prior_lows[-1]["price"]:
                            seq_end=m; break
                    if seq_end is not None: break
        if seq_end is None or seq_end+1>=len(entry_bars): continue
        entry=entry_bars[seq_end+1]["open"]
        seq=entry_bars[touch:seq_end+1]
        buffer=0.1*(e_atr[seq_end] or 0)
        stop=(min(b["low"] for b in seq)-buffer) if z["side"]=="Long" else (max(b["high"] for b in seq)+buffer)
        if entry==stop: continue
        risk=abs(entry-stop)
        target=entry+target_r*risk if z["side"]=="Long" else entry-target_r*risk
        exit_i=None; exit_price=None; outcome=None
        for n in range(seq_end+1,len(entry_bars)):
            b=entry_bars[n]
            if z["side"]=="Long":
                hit_stop=b["low"]<=stop; hit_target=b["high"]>=target
            else:
                hit_stop=b["high"]>=stop; hit_target=b["low"]<=target
            if hit_stop or hit_target:
                # Conservative when both levels touched in the same 15m bar.
                if hit_stop:
                    exit_price=stop; outcome="Loss"
                else:
                    exit_price=target; outcome="Win"
                exit_i=n; break
        if exit_i is None: continue
        gross=((exit_price-entry)/risk) if z["side"]=="Long" else ((entry-exit_price)/risk)
        trades.append({"instrument":instrument,"zone_tf":zone_tf,"side":z["side"],"zone_top":z["top"],"zone_bottom":z["bottom"],
                       "zone_created":z["source_at"],"touch_time":entry_bars[touch]["timestamp"].isoformat(),
                       "entry_time":entry_bars[seq_end+1]["timestamp"].isoformat(),"entry":entry,"stop":stop,"target":target,
                       "exit_time":entry_bars[exit_i]["timestamp"].isoformat(),"exit":exit_price,"outcome":outcome,
                       "gross_r":round(gross,4),"risk_pct":risk_pct,"status":"Closed"})
        z["used"]=True
    vals=[t["gross_r"] for t in trades]
    wins=[v for v in vals if v>0]; losses=[v for v in vals if v<0]
    net=sum(vals); gross_w=sum(wins); gross_l=abs(sum(losses))
    equity=0; peak=0; max_dd=0
    for v in vals:
        equity+=v; peak=max(peak,equity); max_dd=max(max_dd,peak-equity)
    return {"trades":trades,"metrics":{"zone_candidates":len(zones),"trades":len(vals),
      "wins":len(wins),"losses":len(losses),"win_rate_pct":round(100*len(wins)/len(vals),2) if vals else 0,
      "net_r":round(net,3),"avg_r":round(net/len(vals),3) if vals else 0,
      "profit_factor":round(gross_w/gross_l,3) if gross_l else (None if not gross_w else "∞"),
      "max_drawdown_r":round(max_dd,3),"expectancy_r":round(net/len(vals),3) if vals else 0},
      "warnings":["Prototype engine: no spread, commission, slippage, funding, or broker-specific fill simulation is applied.",
                  "Uses one supplied source-timeframe CSV and one 15-minute CSV. Ensure timestamps and session/timezone conventions align.",
                  "Swing and displacement settings are research parameters, not validated profitability claims.",
                  "Zones with no closed trade are not included in trade metrics; review candidate counts and missed setups."]}
